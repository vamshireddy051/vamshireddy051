package com.vamshi.wheels.controller;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vamshi.wheels.Service.CustomerService;
import com.vamshi.wheels.dao.CustomerDao;
import com.vamshi.wheels.model.Customer;
import com.vamshi.wheels.model.AddProduct;
@Controller
public class AdminController {
	@Autowired
	CustomerService customerService;
	@RequestMapping("/AddProduct")
	public ModelAndView addProduct()
	{
		AddProduct addProduct=new AddProduct();
		System.out.println("add new product");
		return new ModelAndView("addProduct","addNewItem",addProduct);
	}
	
	
	
    @RequestMapping("/ViewCustomers")
	public ModelAndView ViewCustomer() throws JsonGenerationException, JsonMappingException, IOException
	{
	    List<Customer> list=customerService.viewCustomer();  
		System.out.println("now im in view customer method in admin controller");
		System.out.println("list:"+list);
		ObjectMapper mapper=new ObjectMapper();
		String listJSON=mapper.writeValueAsString(list);
		System.out.println();
		return new ModelAndView("ViewCustomers","listOfCustomers",listJSON);
		
		
	}
}
