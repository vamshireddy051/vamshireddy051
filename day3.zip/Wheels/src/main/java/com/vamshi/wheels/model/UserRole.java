package com.vamshi.wheels.model;

import javax.persistence.Entity;

@Entity
public class UserRole {
     @javax.persistence.Id
	public int Id;
	public String authority;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
}
