package com.vamshi.wheels.controller;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vamshi.wheels.Service.AddProductService;
import com.vamshi.wheels.Service.CustomerService;
import com.vamshi.wheels.model.Customer;
import com.vamshi.wheels.model.AddProduct;

@Controller
public class AdminController {
	@Autowired
	AddProductService addproductservice;
	@Autowired
	CustomerService customerService;
	@RequestMapping("/AddProduct")
	public ModelAndView addProduct()
	{
		AddProduct addProduct=new AddProduct();
		System.out.println("add new product");
		return new ModelAndView("addProduct","addNewItem",addProduct);
	}
	
	
	
    @RequestMapping("/ViewCustomers")
	public ModelAndView ViewCustomer() throws JsonGenerationException, JsonMappingException, IOException 
	{
	    List<Customer> list=customerService.viewCustomer();  
		System.out.println("now im in view customer method in admin controller");
		System.out.println("list:"+list);
		ObjectMapper mapper=new ObjectMapper();
		String listJSON=mapper.writeValueAsString(list);
		System.out.println();
		return new ModelAndView("ViewCustomers","listOfCustomers",listJSON);
		
		
	}
    @RequestMapping("/addProductItem")
  	public ModelAndView  newProduct(@Valid@ModelAttribute ("addNewItem") AddProduct addProduct, BindingResult bindingresult )
  	{
	   System.out.println("now im in addproduct method");
  	   if (bindingresult.hasErrors())
  	   {
  		   System.out.println("my if condition is true in addproduct");
  		   
  		   return new ModelAndView("addProduct");
  		 
  	   }
  	 addproductservice.addProduct(addProduct);
  	 return new ModelAndView("success");
  	}
  	 
}
