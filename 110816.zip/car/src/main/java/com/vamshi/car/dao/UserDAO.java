package com.vamshi.car.dao;

import java.util.*;

import com.vamshi.car.model.*;
public interface UserDAO
{

	public void saveOrUpdate(User user);
	

}
