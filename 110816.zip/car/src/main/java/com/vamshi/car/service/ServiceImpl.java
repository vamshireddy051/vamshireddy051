package com.vamshi.car.service;
import com.vamshi.car.dao.*;
import com.vamshi.car.model.*;

import java.lang.annotation.Annotation;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ServiceImpl implements Service
{
	@Autowired
	private UserDAO udao;
	
	@Transactional
	public void setUserDao(UserDAO udao)
	{
		this.udao=udao;
	}
	@Transactional
	public void saveOrUpdate(User user) {
		udao.saveOrUpdate(user);
		
	}
	@Override
	public Class<? extends Annotation> annotationType() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String value() {
		// TODO Auto-generated method stub
		return null;
	}


}