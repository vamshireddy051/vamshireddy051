package com.vamshi.car.service;
import com.vamshi.car.model.*;
public interface Service 
{
	
	public void saveOrUpdate(User user);
}