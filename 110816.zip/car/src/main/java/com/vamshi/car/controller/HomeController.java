package com.vamshi.car.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController
{
	
	ModelAndView home;
	@RequestMapping("/")
public ModelAndView HomeData()
{
		home = new ModelAndView("Home");
	return home;
}

	ModelAndView login;
	@RequestMapping("/Login")
public ModelAndView Login()
{
		login = new ModelAndView("Login");
	return login;
}

	
}
