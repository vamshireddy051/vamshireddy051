package com.vamshi.carbe.dao;

import java.util.List;

import com.vamshi.carbe.model.User;
import com.vamshi.carbe.model.UserDetails;



public interface UserDAO {


	public List<User> list();

	public User get(String id);

	//public void saveOrUpdate(User user);
	
	public void saveOrUpdate(User user);

	public void delete(String id);
	
	public boolean isValidUser(String id, String name);


}
