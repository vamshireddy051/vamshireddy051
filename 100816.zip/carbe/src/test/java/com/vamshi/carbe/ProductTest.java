package com.vamshi.carbe;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.vamshi.carbe.dao.ProductDAO;
import com.vamshi.carbe.model.Product;

public class ProductTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.vamshi.carbe");
		context.refresh();
		
		
	   ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
	   
	   Product product = 	(Product) context.getBean("product");
	   product.setId("001");
	   product.setName("classic");
	   product.setDescription("rare");
	   productDAO.saveOrUpdate(product);
	   
	   
	   
	   
	
	  }
		
		
		
	}

