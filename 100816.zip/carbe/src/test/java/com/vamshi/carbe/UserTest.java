package com.vamshi.carbe;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.vamshi.carbe.dao.UserDAO;
import com.vamshi.carbe.model.User;

public class UserTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.vamshi.carbe");
		context.refresh();
		
		
	  UserDAO userDAO = (UserDAO) context.getBean("userDAO");
	   
	   User user = 	(User) context.getBean("user");
	   user.setId("001");
	   user.setPassword("classic");
	   user.setAdmin(true);
	   userDAO.saveOrUpdate(user);
	   
	   
	   
	   
	
	  }
		
		
		
	}

