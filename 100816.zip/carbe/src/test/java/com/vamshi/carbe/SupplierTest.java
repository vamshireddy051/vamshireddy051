package com.vamshi.carbe;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.vamshi.carbe.dao.SupplierDAO;
import com.vamshi.carbe.model.Supplier;

public class SupplierTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.vamshi.carbe");
		context.refresh();
		
		
	   Supplier SupplierDAO = (Supplier) context.getBean("supplierDAO");
	   
	   Supplier supplier = 	(Supplier) context.getBean("supplier");
	   supplier.setId("001");
	   supplier.setName("classic");
	   supplier.setAddress("rare");
	   
	   
	   
	   
	
	  }
		
		
		
	}

