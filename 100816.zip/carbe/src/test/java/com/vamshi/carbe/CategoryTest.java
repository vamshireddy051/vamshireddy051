package com.vamshi.carbe;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.vamshi.carbe.dao.CategoryDAO;
import com.vamshi.carbe.model.Category;

public class CategoryTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.vamshi.carbe");
		context.refresh();
		
		
	   CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	   
	   Category category = 	(Category) context.getBean("category");
	   category.setId("001");
	   category.setName("classic");
	   category.setDes("rare");
	   categoryDAO.saveOrUpdate(category);
	   
	   
	   
	   
	
	  }
		
		
		
	}

