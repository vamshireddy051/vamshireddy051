package com.vamshi.wheels.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vamshi.wheels.dao.CustomerDao;
import com.vamshi.wheels.model.Customer;
@Service
public class CustomerServiceImpl implements CustomerService {

  @Autowired
  CustomerDao customerdao;
	public void addCustomer(Customer customer) {
	customerdao.addCustomer(customer);
	
		
	}
	

}
