package com.vamshi.wheels.Service;

import com.vamshi.wheels.model.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer);

}
