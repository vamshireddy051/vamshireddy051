package com.vamshi.wheels.dao;

import com.vamshi.wheels.model.Customer;

public interface CustomerDao {
	
	public void addCustomer(Customer customer);

}
