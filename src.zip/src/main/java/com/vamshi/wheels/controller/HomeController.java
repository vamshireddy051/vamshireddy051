package com.vamshi.wheels.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vamshi.wheels.Service.CustomerService;
import com.vamshi.wheels.model.Customer;

@Controller
public class HomeController {
	@Autowired
	CustomerService customerService;
	// this is the first mapping of my home page
	@RequestMapping("/")
	public  ModelAndView front()
	{
		System.out.println("Front page() is called");
		return new ModelAndView("Home");
	}
	// when signIn is clicked this method is called 
   @RequestMapping("/signInMapping")
	public ModelAndView signInn()
	{
	   
	   System.out.println("signIn() is called");
		return new ModelAndView("signIn");
	}
   /* when signUp is  clicked this method is called Customerkey 
    * takes input values from spring 
    * and customer object carries this to model and saves in DB
    * post method provides security to the username and password*/
   @RequestMapping("/signUp")
	public ModelAndView signUpp()
	{
	   Customer customer=new Customer();
	   System.out.println("signUp() is called");
		return new ModelAndView("signUp","Customerkey",customer);
	}
    /* data from the object is copied from customer object to formal parameter fresh
     * print to to check data get the data from object
      */
   @RequestMapping("/register")
  	public ModelAndView  newRegistration(@Valid@ModelAttribute ("Customerkey") Customer fresh, BindingResult bindingresult )
  	{
  	   if (bindingresult.hasErrors())
  	   {
  		   return new ModelAndView("signUp");
  		 
  	   }
  	   System.out.println("UserName:" +fresh.getUsername());
  	   System.out.println("Password:" +fresh.getPassword());
  	   customerService.addCustomer(fresh);
  		return new ModelAndView("signUp");
  	}  
}
